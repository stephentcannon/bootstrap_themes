This folder contains only demo data.
Delete the entire folder on production.