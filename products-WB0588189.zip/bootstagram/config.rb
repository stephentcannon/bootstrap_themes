# Dependencies

require "sass"

# Config

css_dir = "css"
sass_dir = "sass"

output_style = :expanded